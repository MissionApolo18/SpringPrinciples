package mx.unam.aragon.inicio;

import mx.unam.aragon.modelo.Profesor;

public class MetodoDos {
    public static void main(String[] args) {
        Profesor profesor = new Profesor();
        profesor.setNombre("Jorge");
    }
}
