package mx.unam.aragon.modelo;

public class Reportes implements Responsabilidad {

    @Override
    public void realizar() {
        System.out.println("Realizando Reporte");
    }
}
