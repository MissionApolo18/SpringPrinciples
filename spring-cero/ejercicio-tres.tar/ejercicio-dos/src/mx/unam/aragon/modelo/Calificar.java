package mx.unam.aragon.modelo;

public class Calificar implements Responsabilidad {
    @Override
    public void realizar() {
        System.out.println("Califica exámenes");
    }
}
