package mx.unam.aragon.modelo;

public class ExplicarClases implements Responsabilidad{
    @Override
    public void realizar() {
        System.out.println("Imparte clases");
    }
}
