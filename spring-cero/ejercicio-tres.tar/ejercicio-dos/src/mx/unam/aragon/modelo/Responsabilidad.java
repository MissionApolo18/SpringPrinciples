package mx.unam.aragon.modelo;

public interface Responsabilidad {
    public void realizar();
}
