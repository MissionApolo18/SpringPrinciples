package mx.unam.aragon.modelo;

public class Responsabilidades {
    public Responsabilidades() {}
    public void explicarClases() {
        System.out.println("Imparte clases");
    }
    public void reportes() {
        System.out.println("Realiza reportes");
    }
    public void calificar() {
        System.out.println("Califica exámenes");
    }
}
